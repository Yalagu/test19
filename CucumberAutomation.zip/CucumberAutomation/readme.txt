
 --------------------------------------------------------------------------------------------------------------------


 Run Script using MVN:
 mvn clean test -DsuiteXmlFile='testng.xml' -Dbrowser='edge' -D"cucumber.filter.tags=@SignUp"
 --------------------------------------------------------------------------------------------------------------------
1.If we want to generate cucumber report execute in TestRunner.java file.
2.For Local Execution You can use Feature file Execution.

Run below Cmd & get device name
        1. adb devices

Pass the device name under BaseClass >>> setDeviceName("emulator-5554")

install appium server using below link

https://github.com/appium/appium-desktop/releases

Open Appium server & click on Advanced.

select check box override session & start server.

Now good to start.

 --------------------------------------------------------------------------------------------------------------------

 To execute Entire suite

mvn clean test verify -D"cucumber.filter.tags=@SignUp"

mvn clean test verify -D"cucumber.filter.tags=@Regression"

 --------------------------------------------------------------------------------------------------------------------



